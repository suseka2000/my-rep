//
//  calculatorApp.swift
//  calculator
//
//  Created by Константин Государев on 01.12.2023.
//

import SwiftUI

@main
struct calculatorApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
