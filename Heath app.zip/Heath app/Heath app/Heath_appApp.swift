//
//  Heath_appApp.swift
//  Heath app
//
//  Created by Константин Государев on 08.01.2024.
//

import SwiftUI

@main
struct Heath_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
